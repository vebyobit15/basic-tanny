<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          ข้อมูลการบริการ
      </h2>
 <?php $__env->endSlot(); ?>
  <div class="py-12">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
            <div class="search_box pull-right">  
            <form class="" method="get" action="/searchAirport/search">   
            <input type="text" placeholder="ค้นหาตามเลขบัตรประชาชน" name="search" />
            </form>
            </div>
            <div class="card-header">ตารางข้อมูลบริการ</div>
<table class="table">
  <thead>
    <tr>
      <th scope="col">ลำดับ</th>
      <th scope="col">เลขบัตรประชาชน</th>
      <th scope="col">เลขทะเบียนรถ</th>
      <th scope="col">รุ่นรถ</th>
      <th scope="col">รูปภาพ</th>
      <th scope="col">บันทึกเมื่อ</th>
      <th scope="col">ค่าใช้จ่าย</th>
      <th scope="col">แก้ไข</th>
      <th scope="col">ลบข้อมูล</th>
      <th scope="col">พิมพ์</th>
    </tr>
  </thead>
  <tbody>
      
      <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($service->firstItem()+$loop->index); ?></th>
      <td><?php echo e($row->customer_number); ?></td>
      <td><?php echo e($row->service_carnumber); ?></td>
      <td><?php echo e($row->service_carbrand); ?></td>
      <td>
          <img src="<?php echo e(asset($row->service_image)); ?>" alt="" width="70px" height="70px">
      </td>
      <td>
          <?php if($row->created_at == NULL): ?>
            ไม่ถูกบันทึก
          <?php else: ?>
            <?php echo e(Carbon\Carbon::parse($row->created_at)->diffForHumans()); ?>

          <?php endif; ?>
      </td>
      <td><?php echo e($row->service_price); ?> บาท</td>
      <td>
          <a href="<?php echo e(url('/service/edit/'.$row->id)); ?>" class="btn btn-info">ดูข้อมูลเพิ่มเติม/แก้ไข</a>
      </td>
      <td>
          <a href="<?php echo e(url('/service/delete/'.$row->id)); ?>" class="btn btn-danger" onclick="return confirm('คุณต้องการลบข้อมูลบริการนี้หรือไม่')">ลบข้อมูล</a>
      </td>
      <td>
      <a href="<?php echo e(url('/service/print/'.$row->id)); ?>" class="btn btn-success">พิมพ์</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($service->links()); ?>

            </div>
            </div>    
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
 <?php /**PATH C:\xampp\htdocs\basic-tanny\resources\views/admin/service/index.blade.php ENDPATH**/ ?>