<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            แก้ไขข้อมูล
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                <div class="card">
                        <div class="card-header">แบบฟอร์มแก้ไขข้อมูล</div>
                        <div class="card-body">
                            <form action="<?php echo e(url('/service/update/'.$service->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                                <!-- ประเภทรถ -->
                                <div class="form-group">
                                <label for="service_cartype">ประเภทรถ</label>
                                <input type="text" class="form-control" name="service_cartype" value="<?php echo e($service->service_cartype); ?>" placeholder="<?php echo e($service->service_cartype); ?>">
                                <label for="service_cartype"><u><i>ประเภท1:รถยนต์ ประเภทที่2:รถจักรยานยนต์ ประเภทที่3:รถอื่นๆ</u></i></label>
                                </div>
                                <?php $__errorArgs = ['service_cartype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- ยี่ห้อรถ -->
                                <div class="form-group">
                                <label for="service_cartype">ยี่ห้อรถ</label>
                                <input type="text" class="form-control" name="service_carbrand" value="<?php echo e($service->service_carbrand); ?>" placeholder="<?php echo e($service->service_carbrand); ?>">
                                </div>
                                <?php $__errorArgs = ['service_carbrand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- สีรถ -->
                                <div class="form-group">
                                <label for="service_carcolor">สีรถ</label>
                                <input type="text" class="form-control" name="service_carcolor" value="<?php echo e($service->service_carcolor); ?>" placeholder="<?php echo e($service->service_carcolor); ?>">
                                </div>
                                <?php $__errorArgs = ['service_carcolor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- เลขทะเบียนรถ -->
                                <div class="form-group">
                                <label for="service_carnumber">เลขทะเบียนรถ</label>
                                <input type="text" class="form-control" name="service_carnumber" value="<?php echo e($service->service_carnumber); ?>" placeholder="<?php echo e($service->service_carnumber); ?>">
                                </div>
                                <?php $__errorArgs = ['service_carnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- เลขบัตรประชาชน -->
                                <div class="form-group">
                                <label for="customer_name">เลขบัตรประชาชน</label>
                                <input type="text" class="form-control" name="customer_number" value="<?php echo e($service->customer_number); ?>" placeholder="<?php echo e($service->customer_number); ?>">
                                </div>
                                <?php $__errorArgs = ['customer_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- ชื่อผู้ใช้บริการ -->
                                <div class="form-group">
                                <label for="customer_name">ชื่อผู้ใช้บริการ</label>
                                <input type="text" class="form-control" name="customer_name" value="<?php echo e($service->customer_name); ?>" placeholder="<?php echo e($service->customer_name); ?>">
                                </div>
                                <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- เบอร์โทรศัพท์ -->
                                <div class="form-group">
                                <label for="customer_telnumber">เบอร์โทรศัพท์</label>
                                <input type="text" class="form-control" name="customer_telnumber" value="<?php echo e($service->customer_telnumber); ?>" placeholder="<?php echo e($service->customer_telnumber); ?>">
                                </div>
                                <?php $__errorArgs = ['customer_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- ค่าใช้จ่ายการใช้บริการ -->
                                <div class="form-group">
                                <label for="service_price">ค่าใช้จ่ายการใช้บริการ</label>
                                <input type="text" class="form-control" name="service_price" value="<?php echo e($service->service_price); ?>" placeholder="<?php echo e($service->service_price); ?>">
                                </div>
                                <?php $__errorArgs = ['service_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!-- รูปภาพ -->
                                <div class="form-group">
                                <label for="service_image">ภาพประกอบ</label>
                                <input type="file" class="form-control" name="service_image" value="<?php echo e($service->service_image); ?>">
                                </div>
                                <?php $__errorArgs = ['service_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                                <input type="hidden" name="old_image" value="<?php echo e($service->service_image); ?>" >
                                <div class="form-group">
                                    <img src="<?php echo e(asset($service->service_image)); ?>" alt="" width="200px" height="200px">
                                </div>
                                <br>
                                <input type="submit" value="อัพเดต" class="btn btn-primary">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\basic-tanny\resources\views/admin/service/edit.blade.php ENDPATH**/ ?>