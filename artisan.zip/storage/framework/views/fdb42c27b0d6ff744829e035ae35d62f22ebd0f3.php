<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            สวัสดี<?php echo e(Auth::user()->name); ?>ยินดีต้อนรับสู่TannysApp
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <?php if(session("success")): ?>
                        <div class="alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <div class="card">
                    <div class="card-header">ตารางข้อมูลแผนก</div>
                    <table class="table">
  <thead>
    <tr>
      <th scope="col">ลำดับ</th>
      <th scope="col">ชื่อแผนก</th>
      <th scope="col">ไอดี</th>
      <th scope="col">สร้างเมื่อ</th>
      <th scope="col">แก้ไข</th>
      <th scope="col">ลบข้อมูล</th>
    </tr>
  </thead>
  <tbody>
      
      <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($department->firstItem()+$loop->index); ?></th>
      <td><?php echo e($row->department_name); ?></td>
      <td><?php echo e($row->user->name); ?></td>
      <td>
          <?php if($row->created_at == NULL): ?>
            ไม่ถูกบันทึก
          <?php else: ?>
            <?php echo e(Carbon\Carbon::parse($row->created_at)->diffForHumans()); ?>

          <?php endif; ?>
      </td>
      <td>
          <a href="<?php echo e(url('/department/edit/'.$row->id)); ?>" class="btn btn-primary">แก้ไข</a>
      </td>
      <td>
          <a href="<?php echo e(url('/department/softdelete/'.$row->id)); ?>" class="btn btn-warning">ลบข้อมูล</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($department->links()); ?>

                    </div>
                    <?php if(count($trashDepartment)>0): ?>
                    <div class="card my-2" ></div>
                    <div class="card-header">ถังขยะ</div>
                    <table class="table">
  <thead>
    <tr>
      <th scope="col">ลำดับ</th>
      <th scope="col">ชื่อแผนก</th>
      <th scope="col">ไอดี</th>
      <th scope="col">สร้างเมื่อ</th>
      <th scope="col">ลบข้อมูล</th>
      <th scope="col">กู้คืนถาวร</th>
    </tr>
  </thead>
  <tbody>
      
      <?php $__currentLoopData = $trashDepartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($trashDepartment->firstItem()+$loop->index); ?></th>
      <td><?php echo e($row->department_name); ?></td>
      <td><?php echo e($row->user->name); ?></td>
      <td>
          <?php if($row->created_at == NULL): ?>
            ไม่ถูกบันทึก
          <?php else: ?>
            <?php echo e(Carbon\Carbon::parse($row->created_at)->diffForHumans()); ?>

          <?php endif; ?>
      </td>
      <td>
          <a href="<?php echo e(url('/department/restore/'.$row->id)); ?>" class="btn btn-success">กู้คืนข้อมูล</a>
      </td>
      <td>
          <a href="<?php echo e(url('/department/delete/'.$row->id)); ?>" class="btn btn-danger">ลบถาวร</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php echo e($trashDepartment->links()); ?>

<?php endif; ?>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">แบบฟอร์ม</div>
                        <div class="card-body">
                            <form action="<?php echo e(route('addDepartment')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                <label for="department_name">ชื่อแผนก</label>
                                <input type="text" class="form-control" name="department_name">
                                </div>
                                <?php $__errorArgs = ['department_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger my-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                                <input type="submit" value="บักทึก" class="btn btn-primary">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
 <?php /**PATH C:\xampp\htdocs\basic-tanny\resources\views/admin/department/index.blade.php ENDPATH**/ ?>